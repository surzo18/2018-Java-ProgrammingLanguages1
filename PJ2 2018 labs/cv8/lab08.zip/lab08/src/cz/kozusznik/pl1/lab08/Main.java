package cz.kozusznik.pl1.lab08;

import cz.kozusznik.pl1.*;
import cz.kozusznik.pl1.shapes.manager.CanvasManager;

import java.awt.*;


public class Main {
    public static void main(String[] args)  {
        CanvasManager.getInstance();
    }
}