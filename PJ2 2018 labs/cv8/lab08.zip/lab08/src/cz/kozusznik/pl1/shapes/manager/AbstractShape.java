package cz.kozusznik.pl1.shapes.manager;

import cz.kozusznik.pl1.shapes.Position;
import cz.kozusznik.pl1.shapes.tools.IMovable;

public abstract class AbstractShape implements IMovable, IPaintable {

}
